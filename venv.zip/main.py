import requests
import os.path


class YaUploader:
    def __init__(self, token: str):
        self.token = TOKEN

    def upload(self, file_path: str):
        """Метод загружает файл на яндекс диск"""
        file_name = os.path.basename(file_path)
        with open(file_path, 'rb') as file:
            file_name = file_path.split('/')[-1]
            # указываем путь на Яндекс.Диске, куда необходимо загрузить файл
            url = f"https://cloud-api.yandex.net:443/v1/disk/resources/upload?path=app:/{file_name}"
            headers = {'Authorization': f'OAuth {self.token}'}
            response = requests.put(url, data=file, headers=headers)
            response.raise_for_status()

if __name__ == '__main__':
    # Получить путь к загружаемому файлу и токен от пользователя
    path_to_file = "/home/igor/Рабочий стол/2/2.jpg"
    TOKEN = "y0_AgAAAABoKIDDAADLWwAAAADamJTF4viWDgxnRSCBaUCfO0ECPfJIYNs"
    uploader = YaUploader(TOKEN)
    uploader.upload(path_to_file)

# /home/igor/Рабочий стол/2/2.jpg
# y0_AgAAAABoKIDDAADLWwAAAADamJTF4viWDgxnRSCBaUCfO0ECPfJIYNs